// JavaScript Document

document.write("ʹ��JavaScript�ű�ѭ�����helloworld");
for(var i=0;i<5;i++){
document.write("<h3>Hello World</h3>");
}
document.write("<h1>Hello World</h1>");